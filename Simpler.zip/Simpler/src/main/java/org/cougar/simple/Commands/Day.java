package org.cougar.simple.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

public class Day implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender commandSender, Command command, String s, String[] strings) {



        if (commandSender instanceof ConsoleCommandSender) {
            Bukkit.getWorld("world").setTime(1);
            Bukkit.getConsoleSender().sendMessage(ChatColor.GREEN + "Now its day!");

        } else if (commandSender instanceof Player) {

            Player p = (Player) commandSender;
            Bukkit.getWorld(p.getWorld().getName()).setTime(1);
            p.sendMessage(ChatColor.GREEN + "Now its day!");
        }

        return true;
    }
}
