package org.cougar.simple.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

public class Thunder implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender commandSender, Command command, String s, String[] strings) {



        if (commandSender instanceof ConsoleCommandSender) {
            Bukkit.getWorld("world").setThundering(true);
            Bukkit.getConsoleSender().sendMessage(ChatColor.GREEN + "Now its Thunderstorm weather!");

        } else if (commandSender instanceof Player) {

            Player p = (Player) commandSender;
            Bukkit.getWorld(p.getWorld().getName()).setThundering(true);
            p.sendMessage(ChatColor.GREEN + "Now its Thunderstorm weather!");
        }

        return true;
    }
}
