package org.cougar.simple.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

public class Noon implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender commandSender, Command command, String s, String[] strings) {



        if (commandSender instanceof ConsoleCommandSender) {
            Bukkit.getWorld("world").setTime(6000);
            Bukkit.getConsoleSender().sendMessage(ChatColor.GREEN + "Now its noon!");

        } else if (commandSender instanceof Player) {

            Player p = (Player) commandSender;
            Bukkit.getWorld(p.getWorld().getName()).setTime(6000);
            p.sendMessage(ChatColor.GREEN + "Now its noon!");
        }

        return true;
    }
}
