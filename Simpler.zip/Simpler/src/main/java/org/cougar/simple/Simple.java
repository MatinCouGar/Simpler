package org.cougar.simple;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;
import org.cougar.simple.Commands.*;

public final class Simple extends JavaPlugin {

    @Override
    public void onEnable() {
        // Registration
        getCommand("tDay").setExecutor(new Day());
        getCommand("tNight").setExecutor(new Night());
        getCommand("tNoon").setExecutor(new Noon());
        getCommand("wRain").setExecutor(new Rain());
        getCommand("wClear").setExecutor(new Clear());
        getCommand("wThunder").setExecutor(new Thunder());


        Bukkit.getConsoleSender().sendMessage(ChatColor.GREEN + "Simple Plugin Enabled");
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
